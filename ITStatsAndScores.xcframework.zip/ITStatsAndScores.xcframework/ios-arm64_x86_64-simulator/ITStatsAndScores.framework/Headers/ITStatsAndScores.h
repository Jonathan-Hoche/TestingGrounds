//
//  ITStatsAndScores.h
//  ITStatsAndScores
//
//  Created by Admin on 14/08/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for ITStatsAndScores.
FOUNDATION_EXPORT double ITStatsAndScoresVersionNumber;

//! Project version string for ITStatsAndScores.
FOUNDATION_EXPORT const unsigned char ITStatsAndScoresVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ITStatsAndScores/PublicHeader.h>


